1. The figure above shows the page displayed at https://d3qpc9qmib13rk.cloudfront.net/

2. Access the website via website-endpoint: http://my-972154422110-bucket.s3-website-us-east-1.amazonaws.com/index.html


3. Access the bucket object via its S3 object URL: https://my-972154422110-bucket.s3.amazonaws.com/index.html